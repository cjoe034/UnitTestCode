package com.adt.anagram3

import android.app.Activity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.junit.After
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.powermock.core.classloader.annotations.PowerMockIgnore
import org.powermock.core.classloader.annotations.PrepareForTest
import org.powermock.reflect.Whitebox
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
@PowerMockIgnore("org.mockito.*", "org.robolectric.*", "android.*")
class MainActivityTest {
    @Before
    fun setUp() {
    }

    @After
    fun tearDown() {
    }

    @Test
    fun testOnCreate() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).create().get()
        Assert.assertNotNull(activity)
    }

    @Test
    fun testOnResume() {
        val activityController = Robolectric.buildActivity(MainActivity::class.java).create().start()
        val activity: Activity = activityController.get()
        (activity.findViewById<View>(R.id.input1) as EditText).setText("asdfg")
        (activity.findViewById<View>(R.id.input2) as EditText).setText("adsfg")
        val button:Button = activity.findViewById(R.id.btnCheck)
        activityController.resume()
        button.performClick()

        Assert.assertEquals( "Yes", (activity.findViewById<View>(R.id.answer) as TextView).text )
    }

    @Test
    @PrepareForTest(MainActivity::class)
    fun testCheckForAnagram() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).create().get()
        (activity.findViewById<View>(R.id.input1) as EditText).setText("asdfg")
        (activity.findViewById<View>(R.id.input2) as EditText).setText("adsfg")
        Whitebox.invokeMethod<Any>(activity, "checkForAnagram")
        Assert.assertEquals("Yes", (activity.findViewById<View>(R.id.answer) as TextView).text)

        (activity.findViewById<View>(R.id.input1) as EditText).setText("asdfg")
        (activity.findViewById<View>(R.id.input2) as EditText).setText("adefg")
        Whitebox.invokeMethod<Any>(activity, "checkForAnagram")
        Assert.assertEquals("No", (activity.findViewById<View>(R.id.answer) as TextView).text)
    }
}