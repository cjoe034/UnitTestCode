package com.adt.anagram3

import org.junit.Assert
import org.junit.Test

class AnagramUtilsTest {
    @Test
    fun testIsAnagram(){
        val a = "asdfg"
        val b = "asfgd"
        val c = "asefg"
        val d = "asdfgh"

        var result = AnagramUtils.isAnagram(a, d)
        Assert.assertTrue(!result)

        result = AnagramUtils.isAnagram(a, b)
        Assert.assertTrue(result)

        result = AnagramUtils.isAnagram(a, c)
        Assert.assertTrue(!result)
    }

    @Test
    fun testResultToString(){
        var str:Boolean = true
        var output:String

        output = AnagramUtils.resultToString(str)
        Assert.assertEquals("Yes", output)

        str = false
        output = AnagramUtils.resultToString(str)
        Assert.assertEquals("No", output)
    }

}