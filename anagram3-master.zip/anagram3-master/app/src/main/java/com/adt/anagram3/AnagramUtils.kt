package com.adt.anagram3

import java.util.HashMap

object AnagramUtils {

    fun isAnagram(a:String, b:String): Boolean {

        if (a.length != b.length) {
            return false
        }
        val map: MutableMap<Char, Int> = HashMap()

        for (c in a.toCharArray()) {
            map[c] = if (map.containsKey(c)) map[c]!! + 1 else 1
        }

        for (c in b.toCharArray()) {
            if (map.containsKey(c) && map[c]!! >= 1) {
                map[c] = map[c]!! - 1
            }
        }
        for ((_, value) in map) {
            if (value != 0) {
                return false
            }
        }
        return true
    }

    fun resultToString(result:Boolean): String {
        return when (result) {
            true -> Constants.YES
            false -> Constants.NO
        }
    }
}
