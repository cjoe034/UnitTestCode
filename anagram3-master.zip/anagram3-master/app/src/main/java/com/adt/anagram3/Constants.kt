package com.adt.anagram3

object Constants {

    const val EMPTY_STRING = ""
    const val YES = "Yes"
    const val NO = "No"

}
